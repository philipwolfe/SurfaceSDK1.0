using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
$if$ ($targetframeworkversion$ == 3.5)using System.Linq;
$endif$using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {

    }
}